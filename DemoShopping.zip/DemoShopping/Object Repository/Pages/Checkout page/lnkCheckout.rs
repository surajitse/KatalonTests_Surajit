<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnkCheckout</name>
   <tag></tag>
   <elementGuidId>dc1d1374-defb-434c-8cff-b4888a4a11de</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@href = 'http://cms.demo.katalon.com/checkout/' and (text() = 'Checkout' or . = 'Checkout')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@href = 'https://cms.demo.katalon.com/checkout/' and (text() = 'Checkout' or . = 'Checkout')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>http://cms.demo.katalon.com/checkout/</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Checkout</value>
   </webElementProperties>
</WebElementEntity>
