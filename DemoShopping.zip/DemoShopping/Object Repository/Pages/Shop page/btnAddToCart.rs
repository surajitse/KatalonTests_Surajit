<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btnAddToCart</name>
   <tag></tag>
   <elementGuidId>2c7cf46f-6deb-4765-b1ff-f856b2f93026</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'single_add_to_cart_button button alt']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>single_add_to_cart_button button alt</value>
   </webElementProperties>
</WebElementEntity>
